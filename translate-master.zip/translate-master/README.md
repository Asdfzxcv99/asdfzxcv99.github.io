# Vita3K.github.io

The source code for https://vita3k.org

## Development

```
gem install bundler jekyll
bundle install
bundle exec jekyll serve
```
