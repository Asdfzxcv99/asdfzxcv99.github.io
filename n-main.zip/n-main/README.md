# nano-proxy.github.io

Demo for nano.

Uses "wss://wisp.mercurywork.shop/" as a wisp server.